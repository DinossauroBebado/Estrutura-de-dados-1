#include "lista.h"

int conta_nos_itr (Lista* lista) {
   /*TERMINAR*/
}

int conta_nos_rec (Lista* lista) {
   /*TERMINAR*/
}

int procura_itr (Lista* lista, int elemento) {
   /*TERMINAR*/
}

int procura_rec (Lista* lista, int elemento) {
   /*TERMINAR*/
}

int lista_max_itr (Lista* lista) {
   /*TERMINAR*/
}

/*Você pode usar outras funções aqui se achar necessário!*/
int lista_max_rec (Lista* lista) {
   /*TERMINAR*/
}

int lista_soma_itr (Lista* lista) {
   /*TERMINAR*/
}

int lista_soma_rec (Lista* lista) {
   /*TERMINAR*/
}

/*Você pode usar outras funções aqui se achar necessário!*/
void imprimir_invertida_itr (Lista* lista) {
   /*TERMINAR*/
}

void imprimir_invertida_rec (Lista* lista) {
   /*TERMINAR*/
}

/*Função para criar uma lista encadeada vazia!*/
Lista* criar_lista (void) {
   return NULL;
}

/*Função para inserir um elemento na cabeça de uma lista encadeada!*/
Lista* inserir (Lista *lista, int elem) {
   Lista *novo =(Lista*)malloc(sizeof(Lista));
   novo->info = elem;
   novo->next = lista;
   return novo;
}

/*Função para imprimir uma lista encadeada!*/
void imprimir_lista (Lista *lista) {
   Lista *v; /*var. para percorrer a lista*/
   printf("Lista: ");
   for (v = lista; v != NULL; v = v->next) {
      printf("%d ", v->info);
   }
   printf("\n");
}

/*Função para desalocar uma lista encadeda!*/
void destruir_lista (Lista *l) {
  Lista *aux;
  while (l != NULL) {
    aux = l->next;
    free(l);
    l = aux;
  }
}

